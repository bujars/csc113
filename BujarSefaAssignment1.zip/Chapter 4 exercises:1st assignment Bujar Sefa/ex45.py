#4-5. Summing a Million: Make a list of the numbers from one to one million, and then use min() and max() 
# to make sure your list actually starts at one and ends at one million . 
# Also, use the sum() function to see how quickly Python can add a million numbers .

print('Bujar Sefa assignment 1, exercise 4.5. 6/19/18')
print()

numbers_one_to_mill = []
for value in range(1, 1000001):
    numbers_one_to_mill.append(value)

""" for value in numbers_one_to_mill:
    print(value)
print() """


#NOTE to print max and min and sum, use the functions max(list name) etc.
print(min(numbers_one_to_mill))
print(max(numbers_one_to_mill))
print(sum(numbers_one_to_mill)) #Wow, this does this pretty fast. 
print()
