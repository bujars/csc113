#4-7. Threes: Make a list of the multiples of 3 from 3 to 30 . 
# Use a for loop to print the numbers in your list .

print('Bujar Sefa assignment 1, exercise 4.7. 6/19/18')
print()


multiples_of_three = [value for value in range(3,31,3)]

for value in multiples_of_three:
    print(value)
print()