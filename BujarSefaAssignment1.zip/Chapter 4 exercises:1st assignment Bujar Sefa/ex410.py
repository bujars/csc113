#4-10. Slices: Using one of the programs you wrote in this chapter, 
# add several lines to the end of the program that do the following:

# Print the message, The first three items in the list are: . 
# Then use a slice to print the first three items from that program’s list .

# Print the message, Three items from the middle of the list are: . 
# Use a slice to print three items from the middle of the list .

# Print the message, The last three items in the list are: . 
# Use a slice to print the last three items in the list .


print('Bujar Sefa assignment 1, exercise 4.10. 6/19/18')
print()

cubes = [value**3 for value in range(1,11)]

for value in cubes:
    print(value)
print() 

#Lets work with the cubes from 4.9

print('The first three items in the list are: ')
print(cubes[:3])
print('Three items from the middle of the list are: ')
#Not sure if there is a way to get the middle of a list, but since we know its length is 10, 10/2 = 5, 
# thus the start  one ahead, 4 and end one after 6...but +1 because non-inclusive end
print(cubes[4:7])
print()
print('The last three items in the list are: ')
print(cubes[-3:])
print()