#4-2. Animals: Think of at least three different animals that have a common char- acteristic . 
# Store the names of these animals in a list, and then use a for loop to print out the name of each animal .

print('Bujar Sefa assignment 1, exercise 4.2. 6/17/18')
print()

#NOTE the common characteristic of these animals is that they can all be house pets
animals = ['dog', 'cat', 'hamster', 'bird', 'fish', 'snake']

for animal in animals:
    print(animal)
print()

#Print a statement for each animal

for animal in animals:
    print('The animals that I beleive most people would love as a pet is ' + animal + '.')
print()

#Add a line that at the end that links the animals

for animal in animals:
    print('The animals that I beleive most people would love as a pet is ' + animal + '.')
print('I seriously beleive that all the animals mentioned above could be pets. Seriously, get one!')
print()
