#4-12. More Loops: All versions of foods.py in this section have avoided using for loops when printing to save space . 
# Choose a version of foods.py, and write two for loops to print each list of foods .


print('Bujar Sefa assignment 1, excersize 4.12. 6/19/18')
print()

#I am assuming we just copy from the textbook one of the examples of the food and print the lists? 

my_foods = ['pizza', 'falafel', 'carrot cake'] 
friend_foods = my_foods[:]

my_foods.append('cannoli') 
friend_foods.append('ice cream')

print("My favorite foods are:")
print(my_foods)

print("\nMy friend's favorite foods are:")
print(friend_foods)
print()

#### HERE IS WHAT I ADDED ####

for food in my_foods:
    print(food)
print()

for food in friend_foods:
    print(food)
print()


