#4-6. Odd Numbers: Use the third argument of the range() function to make a list of the odd numbers from 1 to 20 .
#  Use a for loop to print each number .

print('Bujar Sefa assignment 1, exercise 4.6. 6/19/18')
print()

numbers = [value for value in range(1, 21, 2)]

for value in numbers:
    print(value)
print()