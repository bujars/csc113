#4-4. One Million: Make a list of the numbers from one to one million, 
# and then use a for loop to print the numbers . 
# (If the output is taking too long, stop it by pressing ctrl-C or by closing the output window .)

print('Bujar Sefa assignment 1, exercise 4.4. 6/19/18')
print()

numbers_one_to_mill = []
for value in range(1, 1000001):
    numbers_one_to_mill.append(value)

for value in numbers_one_to_mill:
    print(value)
print()