#4-3. Counting to Twenty: Use a for loop to print the numbers from 1 to 20, inclusive .

print('Bujar Sefa assignment 1, exercise 4.3. 6/19/18')
print()


numbers = []
for value in range(1, 21):
    numbers.append(value)
    print(value)
print()



