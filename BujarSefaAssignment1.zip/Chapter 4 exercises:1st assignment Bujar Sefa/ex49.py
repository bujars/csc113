#4-9. Cube Comprehension: Use a list comprehension to generate a list of the first 10 cubes .

print('Bujar Sefa assignment 1, exercise 4.9. 6/19/18')
print()


cubes = [value**3 for value in range(1,11)]

for value in cubes:
    print(value)
print()


##NOTE originally completed this for 4.8....thus refined 4.8 the long way