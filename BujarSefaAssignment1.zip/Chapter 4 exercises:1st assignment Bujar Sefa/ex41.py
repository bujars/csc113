#4-1. Pizzas: Think of at least three kinds of your favorite pizza . 
# Store these pizza names in a list, and then use a for loop to print the name of each pizza .

print('Bujar Sefa assignment 1, excersize 4.1. 6/17/18')
print()

pizzas = ['cheese', 'mushroom', 'grandma']

for pizza in pizzas:
    print(pizza)
print()

#Printing sentence w/ Pizzas names

for pizza in pizzas:
    print('My favorite pizza is ' + pizza + ' pizza.')
print()

#Adding line out the end 
for pizza in pizzas:
    print('My favorite pizza is ' + pizza + ' pizza.')
print('Who doesn\'t love pizza? I know I do!')
print()