# 6-7. People: Start with the program you wrote for Exercise 6-1 (page 102).
#  Make two new dictionaries representing different people, and store all three dictionaries in a list called people. 
# Loop through your list of people. As you loop through the list, print everything you know about each person.

print('Bujar Sefa assignment 2, excersize 6.7. 6/30/18')
print()


person1 = {
    'name':'Jorge', 
    'last name':'Diaz',
    'age': 19,
    'city':'NYC'
    }

person2 = {
    'name':'Alondra', 
    'last name':'Diaz',
    'age': 20,
    'city':'Las Vegas'
    }

person3 = {
    'name':'Mike', 
    'last name':'Jay',
    'age': 21,
    'city':'San Franciso'
    }

#NOTE how a list is made with [] brackets and you can just list each dictionary in it. 
people = [person1, person2, person3]



for person in people:
    print(person)
print()

for person in people:
    name = person['name'] + " " + person['last name']
    age = str(person['age'])
    city = person['city']
    print(name + ", of " + city + ", is " + age + " years old.")


''' print("My Person's name is: " + person['name'])
print("My Person's last name is: " + person['last name'])
print("My Person's age is: " + str(person['age']))
print("My Person's city is: " + person['city'])
 '''