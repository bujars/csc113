#6-2. Favorite Numbers: Use a dictionary to store people’s favorite numbers. 
# Think of five names, and use them as keys in your dictionary. 
# Think of a favorite number for each person, and store each as a value in your dictionary. 
# Print each person’s name and their favorite number. For even more fun, poll a few friends and get some actual data for your program.

print('Bujar Sefa assignment 2, excersize 6.2. 6/30/18')
print()

favorite_numbers = {
    'Dan':19,
    "Max":7,
    "John":23,
    "Alce":5,
    'Liger':54
}

for key in favorite_numbers.keys():
    print(key + '\'s favorite number is ' + str(favorite_numbers[key]))
print()

print("My Person's favorite number is: " + str(favorite_numbers['Dan']))
print("My Person's lfavorite number is: " + str(favorite_numbers['Max']))
print("My Person's favorite number is: " + str(favorite_numbers['John']))
print("My Person's favorite number is: " + str(favorite_numbers['Alce']))
print("My Person's favorite number is: " + str(favorite_numbers['Liger']))