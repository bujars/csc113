#6-10. Favorite Numbers: Modify your program from Exercise 6-2 (page 102) 
# so each person can have more than one favorite number. 
# Then print each person’s name along with their favorite numbers.

print('Bujar Sefa assignment 2, excersize 6.10. 6/30/18')
print()

favorite_numbers = {
    'Dan':[19,72, 69, 83, 26],
    "Max":[7, 9, 13, 79, 92],
    "John":[23, 32, 45, 54, 66],
    "Alce":[5, 2, 12, 67, 84, 95],
    'Liger':[54, 68, 33, 47, 91]
}

for person in favorite_numbers:
    print(person + '\'s favorite numbers are: ') 
    for value in favorite_numbers[person]:
        print(value)
    print()
print()
