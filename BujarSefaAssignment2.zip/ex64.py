#6-4. Glossary 2: Now that you know how to loop through a dictionary, 
# clean up the code from Exercise 6-3 (page 102) by replacing your series of print statements with a loop that runs through the dictionary’s keys and values. 
# When you’re sure that your loop works, add five more Python terms to your glossary. 
# When you run your program again, these new words and meanings should automatically be included in the output.



#NOTE NOTE -- originally did it without print statements and with just a loop....

print('Bujar Sefa assignment 2, excersize 6.4. 6/30/18')
print()

#note these definitons were copied from google/wikipedia
glossary = {
    'for loop': 'a sequence of instruction s that is continually repeated until a certain condition is reached.',
    'while loop': 'is a control flow statement that allows code to be executed repeatedly based on a given Boolean condition.',
    'variable': 'a value that can change, depending on conditions or on information passed to the program.',
    'function': 'a style of building the structure and elements of computer programs',
    'python': 'an interpreted, object-oriented programming language similar to PERL, that has gained popularity because of its clear syntax and readability.'
}


for key in glossary.keys():
    print('Definition: ' + key.title() + " - " + glossary[key] + '\n')
print()


print('Glossary with new terms\n')

glossary['c++']='is a general-purpose object-oriented programming (OOP) language, developed by Bjarne Stroustrup, and is an extension of the C language.'
glossary['java']='a general-purpose computer-programming language that is concurrent, class-based, object-oriented, and specifically designed to have as few implementation dependencies as possible.'
glossary['swift']='is a general-purpose, multi-paradigm, compiled programming language developed by Apple Inc. for iOS, macOS, watchOS, tvOS, and Linux.'
glossary['javascript']='is a programming language commonly used in web development. It was originally developed by Netscape as a means to add dynamic and interactive elements to websites.'
glossary['c']='is a high-level and general-purpose programming language that is ideal for developing firmware or portable applications'

for key in glossary.keys():
    print('Definition: ' + key.title() + " - " + glossary[key] + '\n')
print()