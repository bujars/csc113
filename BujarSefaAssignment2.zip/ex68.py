# 6-8. Pets: Make several dictionaries, where the name of each dictionary is the name of a pet. 
# In each dictionary, include the kind of animal and the owner’s name. 
# Store these dictionaries in a list called pets. 
# Next, loop through your list and as you do print everything you know about each pet.

print('Bujar Sefa assignment 2, excersize 6.8. 6/30/18')
print()


dog = {'Type of Pet':'Dog', 'Owner':'Bujar', 'Age':7, 'Color':'Beige', 'Breed':'Pitbull'}
cat = {'Type of Pet':'Cat', 'Owner':'John', 'Age':21, 'Color':'Naked', 'Breed':'Rat'}
bird = {'Type of Pet':'Bird', 'Owner':'Alice', 'Age':56, 'Color':'Blue', 'Breed':'MockingBird'}
fish ={'Type of Pet':'Fish', 'Owner':'Dave', 'Age':4, 'Color':'Orange', 'Breed':'GoldFish'}
snake = {'Type of Pet':'Snake', 'Owner':'Eliza', 'Age':2, 'Color':'Black', 'Breed':'Anaconda'}

pets = [dog, cat, bird, fish, snake]

for pet in pets:
    print(pet)
print()

print("Printing Information on the pets \n")
for pet in pets:
    print(pet['Type of Pet'] + ":")
    for key, value in pet.items():
        print(key + ": " + str(value))
    print()
print()