#6-1. Person: Use a dictionary to store information about a person you know. 
# Store their first name, last name, age, and the city in which they live. Y
# ou should have keys such as first_name, last_name, age, and city. 
# Print each piece of information stored in your dictionary.

print('Bujar Sefa assignment 2, excersize 6.1. 6/30/18')
print()

person = {
    'name':'Jorge', 
    'last name':'Diaz',
    'age': 19,
    'city':'NYC'
    }
for key in person.keys():
    print(person[key])
print()

print("My Person's name is: " + person['name'])
print("My Person's last name is: " + person['last name'])
print("My Person's age is: " + str(person['age']))
print("My Person's city is: " + person['city'])
