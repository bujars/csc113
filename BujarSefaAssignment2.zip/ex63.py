#6-3. Glossary: A Python dictionary can be used to model an actual dictionary. H
# owever, to avoid confusion, let’s call it a glossary.
# 
# Think of five programming words you’ve learned about in the previous chapters. 
# Use these words as the keys in your glossary, and store their meanings as values

# Print each word and its meaning as neatly formatted output. 
# You might print the word followed by a colon and then its meaning, 
# or print the word on one line and then print its meaning indented on a second line. 
# Use the newline character (\n) to insert a blank line between each word-meaning pair in your output.

print('Bujar Sefa assignment 2, excersize 6.3. 6/30/18')
print()

#note these definitons were copied from google/wikipedia
glossary = {
    'for loop': 'a sequence of instruction s that is continually repeated until a certain condition is reached.',
    'while loop': 'is a control flow statement that allows code to be executed repeatedly based on a given Boolean condition.',
    'variable': 'a value that can change, depending on conditions or on information passed to the program.',
    'function': 'a style of building the structure and elements of computer programs',
    'python': 'an interpreted, object-oriented programming language similar to PERL, that has gained popularity because of its clear syntax and readability.'
}


for key in glossary.keys():
    print('Definition: ' + key.title() + " - " + glossary[key] + '\n')
print()