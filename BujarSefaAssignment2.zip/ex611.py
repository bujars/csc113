#6-11. Cities: Make a dictionary called cities. 
# Use the names of three cities as keys in your dictionary. 
# Create a dictionary of information about each city and include the country that the city is in, 
# its approximate population, and one fact about that city. 
# The keys for each city’s dictionary should be something like country, population, and fact. 
# Print the name of each city and all of the infor- mation you have stored about it.

print('Bujar Sefa assignment 2, excersize 6.11. 6/30/18')
print()

cities = {
    'New York City':{'Located in Country - ':'United States of America' , 'Population':'8.538 million', 'Fun Fact - ': 'The first American chess tournament was held in New York in 1843.'},
    'Paris':{'Located in Country - ':'France' , 'Population':'2.244 million', 'Fun Fact - ': 'The Eiffel Tower was supposed to be a temporary installation, intended to stand for 20 years after being built for the 1889 World Fair.'},
    'Rome':{'Located in Country - ':'Italy' , 'Population':'2.868 million', 'Fun Fact - ': 'Rome was founded by two brothers nursed by a she-wolf'}
}

for city, fact in cities.items():
        print('City: ' +city)
        print('Located in Country - ' + fact['Located in Country - ']+ '\nPopulation: '+fact['Population']+ '\nFun Fact - ' + fact['Fun Fact - '])
        print()
print()
