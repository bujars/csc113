# 6-9. Favorite Places: Make a dictionary called favorite_places. T
# hink of three names to use as keys in the dictionary, and store one to three favorite places for each person. 
# to make this exercise a bit more interesting, ask some friends to name a few of their favorite places. 
# Loop through the dictionary, and print each person’s name and their favorite places.

print('Bujar Sefa assignment 2, excersize 6.9. 6/30/18')
print()


favorite_places = {
    'bujar':['New York City', 'Home','School' ],
    'john':['Paris', 'Church', 'Mall'],
    'jorge':['Work', 'Pizza Place', 'Park']
}

for person in favorite_places:
    print(person.title() + '\'s favorite places are:')
    for places in favorite_places[person]:
        print(places)
    print()
print()