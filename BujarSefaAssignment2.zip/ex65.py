# 6-5. Rivers: Make a dictionary containing three major rivers and the country each river runs through. One key-value pair might be 'nile': 'egypt'.
# Use a loop to print a sentence about each river, such as The Nile runs through Egypt.
# Use a loop to print the name of each river included in the dictionary.
# Use a loop to print the name of each country included in the dictionary.

print('Bujar Sefa assignment 2, excersize 6.5. 6/30/18')
print()


rivers = {
    'nile':'egypy',
    'amazon':'brazil',
    'yangtze':'east china'
}

for key in rivers.keys():
    print('The ' + key.title() + " river runs through " + rivers[key] + '\n')
print()

#printing rivers --aka keys
print("The following rivers have been mentioned:")
for key in rivers.keys():
    print(key.title())
print()

#printing countries of rivers -- aka values
print("The following countries have been mentioned:")
for key in rivers.keys():
    print(rivers[key].title())
print()

