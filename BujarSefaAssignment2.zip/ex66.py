# 6-6. Polling: Use the code in favorite_languages.py (page 104).
# Make a list of people who should take the favorite languages poll. 

# Include some names that are already in the dictionary and some that are not.
# Loop through the list of people who should take the poll. 
# If they have already taken the poll, print a message thanking them for responding. 
# If they have not yet taken the poll, print a message inviting them to take the poll.

print('Bujar Sefa assignment 2, excersize 6.6. 6/30/18')
print()


favorite_languages = {
    'jen': 'python',
    'sarah': 'c',
    'edward': 'ruby',
    'phil': 'python',
    }

for name in favorite_languages:
    print(name.title() + "\'s favorite language is " + favorite_languages[name].title())
print()

favorite_languages['bujar']='c'
favorite_languages['jorge']='html'
favorite_languages['chris']='java'


print("Taking the programming language poll: \n")

for name in favorite_languages.keys(): 
    if(favorite_languages[name] =='python' or favorite_languages[name]=='c'):
        print(name.title()+ ', Thank You for taking the poll.')
    else:
        print(name.title()+ ', Please come take the poll. ')
print()