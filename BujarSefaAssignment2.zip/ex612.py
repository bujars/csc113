# 6-12. Extensions: We’re now working with examples that are complex enough that they can be extended in any number of ways. 
# Use one of the example pro- grams from this chapter, a
# nd extend it by adding new keys and values, 
# chang- ing the context of the program or 
# improving the formatting of the output.
# 

#########GOING to work on 6.8 by adding more vdictionaries and printing them better

# 
# 6-8. Pets: Make several dictionaries, where the name of each dictionary is the name of a pet. 
# In each dictionary, include the kind of animal and the owner’s name. 
# Store these dictionaries in a list called pets. 
# Next, loop through your list and as you do print everything you know about each pet.

print('Bujar Sefa assignment 2, excersize 6.12. 6/30/18')
print()

animals = {
'dog': {'Type of Pet':'Dog', 'Owner':'Bujar', 'Age':7, 'Color':'Beige', 'Breed':'Pitbull'},
'cat': {'Type of Pet':'Cat', 'Owner':'John', 'Age':21, 'Color':'Naked', 'Breed':'Rat'},
'bird': {'Type of Pet':'Bird', 'Owner':'Alice', 'Age':56, 'Color':'Blue', 'Breed':'MockingBird'},
'fish': {'Type of Pet':'Fish', 'Owner':'Dave', 'Age':4, 'Color':'Orange', 'Breed':'GoldFish'},
'snake': {'Type of Pet':'Snake', 'Owner':'Eliza', 'Age':2, 'Color':'Black', 'Breed':'Anaconda'},
'zebra': {'Type of Pet':'Zebra', 'Owner':'Jack', 'Age':34, 'Color':'Stripped', 'Breed':'African'},
'giraffe': {'Type of Pet':'Giraffe', 'Owner':'Tommy', 'Age':72, 'Color':'Printed', 'Breed':'African'},
'lion': {'Type of Pet':'Lion', 'Owner':'Eldner', 'Age':18, 'Color':'Orange', 'Breed':'Wild'},
'tiger': {'Type of Pet':'Tiger', 'Owner':'Alexis', 'Age':26, 'Color':'Orange', 'Breed':'Wild'},
'hamster': {'Type of Pet':'Hamster', 'Owner':'Kayla', 'Age':62, 'Color':'Brown', 'Breed':'Rat'},
'gorilla': {'Type of Pet':'Gorilla', 'Owner':'Hamza', 'Age':51, 'Color':'Black', 'Breed':'Ape'},
'monkey': {'Type of Pet':'Monkey', 'Owner':'Peter', 'Age':32, 'Color':'Brown', 'Breed':'Wild'},
'turtle': {'Type of Pet':'Turtle', 'Owner':'Tahsin', 'Age':14, 'Color':'Green', 'Breed':'Slow'},
'shark': {'Type of Pet':'Shark', 'Owner':'Yvonne', 'Age':8, 'Color':'Grey', 'Breed':'Killer'},
'puppy': {'Type of Pet':'Puppy', 'Owner':'Erlyn', 'Age':1, 'Color':'Grey', 'Breed':'Husky'}
}

print('Following will be a list of animals and certain traits.')
print()
for animal, traits in animals.items():
    print('The animal is a ' + animal.title() + '.' )
    print('It\'s traits are: \nType of Pet: ' + traits['Type of Pet'] 
    + '\nOwner: ' + traits['Owner']
    + '\nAge of ' + animal.title() +': '+ str(traits['Age'])
    +'\nColor: '+traits['Color']
    + '\nBreed: '+ traits['Breed'])
    print()
print()


