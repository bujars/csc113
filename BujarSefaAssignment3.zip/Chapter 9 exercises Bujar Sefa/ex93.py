# 9-3. Users: Make a class called User. 
# Create two attributes called first_name and last_name, 
# and then create several other attributes that are typically stored in a user profile. 
# Make a method called describe_user() that prints a summary of the user’s information. 
# Make another method called greet_user() that prints a personalized greeting to the user.
# Create several instances representing different users, and call both methods for each user.

print('Bujar Sefa assignment 3, excersize 9.3. 7/12/18')
print()

class User():
    def __init__(self, first_name, last_name, age, email, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.gender = gender
    def describe_user(self):
        return ('User\'s Information \nFirst Name: ' +
                self.first_name +'\nLast Name: ' +
                self.last_name + '\nAge: ' + 
                str(self.age) + '\nEmail: '+
                self.email + '\nGender: ' +
                self.gender)
    def greet_user(self):
        return 'Welcome, ' + self.first_name + ' ' + self.last_name + '!'

user_1 = User('Bujar', 'Sefa', 18, 'bs@gmail.com', 'M')
user_2 = User('Joe', 'Doe', 25, 'jd@gmail.com', 'M')
user_3 = User('Tania', 'Dello', 21, 'td@gmail.com', 'F')
user_4 = User('Jorge', 'Monzon', 19, 'jm@gmail.com','M')
user_5 = User('Jane', 'Suga', 23, 'js@gmail.com', 'F')
print()
print(user_1.describe_user())
print(user_2.describe_user())
print(user_3.describe_user())
print(user_4.describe_user())
print(user_5.describe_user())
print(user_1.greet_user())
print(user_2.greet_user())
print(user_3.greet_user())
print(user_4.greet_user())
print(user_5.greet_user())