#9-1. Restaurant: Make a class called Restaurant. 
# The __init__() method for Restaurant should store two attributes: 
# a restaurant_name and a cuisine_type. 
# Make a method called describe_restaurant() that prints these two pieces of information, 
# and a method called open_restaurant() that prints a message indi- 
#cating that the restaurant is open.
# Make an instance called restaurant from your class. 
# Print the two attri- butes individually, and then call both methods.



print('Bujar Sefa assignment 3, excersize 9.1. 7/12/18')
print()


class Resturant():
    def __init__(self, name, cuisine):
        self.name = name
        self.cuisine = cuisine
    def describe_restaurant(self):
        return "Resturant " + self.name.title() + " is a wonderful " + self.cuisine + ' cuisine resturnat option.'
    def open_restaurant(self):
        return 'Resturant ' + self.name.title() + ' is now open.'


resturant_1 = Resturant('Joe', 'Italian')
resturant_2 = Resturant('Jorge', 'Mexican')

print('Printing each instance attributes individually')
print(resturant_1.name)
print(resturant_2.name)
print(resturant_1.cuisine)
print(resturant_2.cuisine)
print()

print('Printing each instance with method')
print(resturant_1.describe_restaurant())
print(resturant_1.open_restaurant())
print(resturant_2.describe_restaurant())
print(resturant_2.open_restaurant())

