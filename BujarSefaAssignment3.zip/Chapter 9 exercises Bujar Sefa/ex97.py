#9-7. Admin: An administrator is a special kind of user. 
# Write a class called Admin that inherits from the User class you wrote in Exercise 9-3 (page 166) or Exercise 9-5 (page 171). 
# Add an attribute, privileges, that stores a list of strings like "can add post", 
# "can delete post", "can ban user", and so on. Write a method called show_privileges() 
# that lists the administrator’s set of privileges. Create an instance of Admin, and call your method.

print('Bujar Sefa assignment 3, excersize 9.7. 7/16/18')
print()

class User():
    def __init__(self, first_name, last_name, age, email, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.gender = gender
        self.login_attempts = 0
    def describe_user(self):
        return ('User\'s Information \nFirst Name: ' + 
                self.first_name +'\nLast Name: ' + 
                self.last_name + '\nAge: ' + 
                str(self.age) + '\nEmail: '+
                self.email + '\nGender: ' + 
                self.gender)
    def greet_user(self):
        return 'Welcome, ' + self.first_name + ' ' + self.last_name + '!'
    def increment_login_attempts(self, num):
        self.login_attempts += num
    def reset_login_attempts(self):
        self.login_attempts = 0

class Admin(User):
    def __init__(self, first_name, last_name, age, email, gender, privilages=None):
        super().__init__(first_name, last_name,age, email, gender)
        if privilages is None:
            self.privilages = []
        else:
            self.privilages = privilages
    def show_privileges(self):
        for privilage in self.privilages:
            print(privilage)
        print()





admin = Admin('Bujar','Sefa', 18, 'bs@gmail.com', 'M', ['Can add users', 'Can delete users', 'Can revoke privilages', 'Can privitzie account'])
admin.show_privileges()


