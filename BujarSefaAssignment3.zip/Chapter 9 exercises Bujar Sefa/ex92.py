#9-2. Three Restaurants: Start with your class from Exercise 9-1. 
# Create three different instances from the class, and call describe_restaurant() for each instance.


print('Bujar Sefa assignment 3, excersize 9.2. 7/12/18')
print()



class Resturant():
    def __init__(self, name, cuisine):
        self.name = name
        self.cuisine = cuisine
    def describe_restaurant(self):
        return "Resturant " + self.name.title() + " is a wonderful " + self.cuisine + ' cuisine resturnat option.'
    def open_restaurant(self):
        return 'Resturant ' + self.name.title() + ' is now open.'


resturant_1 = Resturant('Joe', 'Italian')
resturant_2 = Resturant('Jorge', 'Mexican')
resturant_3 = Resturant('Ling-Ling', 'Chinese')
resturant_4 = Resturant('TyTy', 'African')
resturant_5 = Resturant('Hongwo', 'Japanese')


print('Printing each instance with describe method')
print(resturant_1.describe_restaurant())
print(resturant_2.describe_restaurant())
print(resturant_3.describe_restaurant())
print(resturant_4.describe_restaurant())
print(resturant_5.describe_restaurant())
