# 9-8. Privileges: Write a separate Privileges class. 
# The class should have one attribute, privileges, 
# that stores a list of strings as described in Exercise 9-7. 
# Move the show_privileges() method to this class. 
# Make a Privileges instance as an attribute in the Admin class. 
# Create a new instance of Admin and use your method to show its privileges.

print('Bujar Sefa assignment 3, excersize 9.8. 7/16/18')
print()


class User():
    def __init__(self, first_name, last_name, age, email, gender):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
        self.email = email
        self.gender = gender
        self.login_attempts = 0
    def describe_user(self):
        return ('User\'s Information \nFirst Name: ' + 
                self.first_name +'\nLast Name: ' + 
                self.last_name + '\nAge: ' + 
                str(self.age) + '\nEmail: '+
                self.email + '\nGender: ' + 
                self.gender)
    def greet_user(self):
        return 'Welcome, ' + self.first_name + ' ' + self.last_name + '!'
    def increment_login_attempts(self, num):
        self.login_attempts += num
    def reset_login_attempts(self):
        self.login_attempts = 0

class Admin(User):
    def __init__(self, first_name, last_name, age, email, gender, privilages=None):
        super().__init__(first_name, last_name,age, email, gender)
        self.privilages = Privileges(privilages)

class Privileges():
    def __init__(self, privilages =None):
        if privilages is None:
            self.privilages = []
        else:
            self.privilages = privilages
    def show_privileges(self):
        for privilage in self.privilages:
            print(privilage)
        print()

admin = Admin('Bujar','Sefa', 18, 'bs@gmail.com', 'M', ['Can add users', 'Can delete users', 'Can revoke privilages', 'Can privitzie account'])
admin.privilages.show_privileges()
admin.privilages
